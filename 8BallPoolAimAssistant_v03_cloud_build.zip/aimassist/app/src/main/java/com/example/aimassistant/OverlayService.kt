package com.example.aimassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager

class OverlayService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL = "aim_assistant_capture"
    }

    private lateinit var wm: WindowManager
    private var overlay: AimView? = null
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var worker: HandlerThread? = null
    private var workerHandler: Handler? = null
    private val mainHandler = Handler()
    private var screenW = 0
    private var screenH = 0
    @Volatile private var lastAnalysis = 0L

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(10, buildNotification())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        overlay = AimView()
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(overlay, params)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        else @Suppress("DEPRECATION") (intent?.getParcelableExtra(EXTRA_RESULT_DATA) as? Intent)
        if (data != null && projection == null) beginCapture(code, data)
        return START_NOT_STICKY
    }

    private fun beginCapture(resultCode: Int, data: Intent) {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        screenW = metrics.widthPixels; screenH = metrics.heightPixels
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        worker = HandlerThread("ball-analysis").also { it.start() }
        workerHandler = Handler(worker!!.looper)
        reader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, workerHandler)
        virtualDisplay = projection?.createVirtualDisplay(
            "AimAssistantCapture", screenW, screenH, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, workerHandler
        )
        reader?.setOnImageAvailableListener({ r ->
            val now = System.currentTimeMillis()
            if (now - lastAnalysis < 500) {
                val skipped = r.acquireLatestImage()
                skipped?.close()
                return@setOnImageAvailableListener
            }
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            lastAnalysis = now
            try {
                val bitmap = imageToBitmap(image)
                val balls = BallDetector.detect(bitmap)
                bitmap.recycle()
                mainHandler.post { overlay?.updateBalls(balls) }
            } catch (_: Exception) {
            } finally {
                image.close()
            }
        }, workerHandler)
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * screenW
        val padded = Bitmap.createBitmap(screenW + rowPadding / pixelStride, screenH, Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(buffer)
        val cropped = Bitmap.createBitmap(padded, 0, 0, screenW, screenH)
        padded.recycle()
        return cropped
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Aim Assistant", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL)
            else @Suppress("DEPRECATION") Notification.Builder(this)
        return builder.setContentTitle("Aim Assistant ativo")
            .setContentText("Análise visual experimental ativa. Pare pelo aplicativo.")
            .setSmallIcon(android.R.drawable.ic_menu_compass).setOngoing(true).build()
    }

    override fun onDestroy() {
        reader?.setOnImageAvailableListener(null, null)
        virtualDisplay?.release(); reader?.close(); projection?.stop()
        worker?.quitSafely()
        overlay?.let { wm.removeView(it) }; overlay = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private inner class AimView : View(this@OverlayService) {
        private val ballPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.CYAN; style = Paint.Style.STROKE; strokeWidth = 3.5f
        }
        private val cuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.YELLOW; style = Paint.Style.STROKE; strokeWidth = 5f
        }
        private val panel = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xCC101827.toInt() }
        private val label = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 25f }
        @Volatile private var balls: List<DetectedBall> = emptyList()

        fun updateBalls(newBalls: List<DetectedBall>) {
            balls = newBalls
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val current = balls
            canvas.drawRoundRect(RectF(18f, 55f, width - 18f, 130f), 16f, 16f, panel)
            canvas.drawText("AIM PRO 0.3  •  bolas candidatas: ${current.size}", 34f, 101f, label)
            for (ball in current) {
                val p = if (ball.isCueCandidate) cuePaint else ballPaint
                canvas.drawCircle(ball.x, ball.y, ball.radius + 5f, p)
                canvas.drawCircle(ball.x, ball.y, 3f, p)
            }
        }
    }
}
