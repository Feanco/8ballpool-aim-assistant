package com.example.aimassistant

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val captureRequest = 4103

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(30, 42, 30, 30)
            setBackgroundColor(0xFF101827.toInt())
        }
        val title = TextView(this).apply {
            text = "8 Ball Pool Aim Assistant PRO"
            textSize = 23f
            setTextColor(0xFFFFFFFF.toInt())
        }
        status = TextView(this).apply {
            text = "\nVersão 0.3 — detector visual experimental. A captura só começa com sua autorização."
            textSize = 15f
            setTextColor(0xFFD1D5DB.toInt())
        }
        val permission = Button(this).apply {
            text = "1. Permitir sobreposição"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else status.text = "Sobreposição autorizada."
            }
        }
        val start = Button(this).apply {
            text = "2. Iniciar detector"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    status.text = "Primeiro permita a sobreposição."
                } else {
                    val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    startActivityForResult(mgr.createScreenCaptureIntent(), captureRequest)
                }
            }
        }
        val stop = Button(this).apply {
            text = "Parar detector"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)); status.text = "Detector parado." }
        }
        layout.addView(title); layout.addView(status)
        layout.addView(permission); layout.addView(start); layout.addView(stop)
        setContentView(layout)
    }

    @Deprecated("Deprecated API retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, OverlayService::class.java).apply {
                putExtra(OverlayService.EXTRA_RESULT_CODE, resultCode)
                putExtra(OverlayService.EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service) else startService(service)
            status.text = "Detector ativo. Os marcadores são experimentais."
        } else if (requestCode == captureRequest) status.text = "Captura cancelada."
    }
}
