package com.example.aimassistant

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs

data class DetectedBall(val x: Float, val y: Float, val radius: Float, val isCueCandidate: Boolean)

object BallDetector {
    // Segmentação simples para protótipo. Não substitui um modelo treinado:
    // interface, reflexos e cores da mesa podem gerar falsos positivos.
    fun detect(bitmap: Bitmap): List<DetectedBall> {
        val scale = 4
        val w = (bitmap.width / scale).coerceAtLeast(1)
        val h = (bitmap.height / scale).coerceAtLeast(1)
        val pixels = IntArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            pixels[y * w + x] = bitmap.getPixel(x * scale, y * scale)
        }
        val mask = BooleanArray(w * h)
        for (i in pixels.indices) {
            val c = pixels[i]
            val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
            val maxC = maxOf(r, g, b); val minC = minOf(r, g, b)
            val saturation = if (maxC == 0) 0f else (maxC - minC).toFloat() / maxC
            val bright = maxC > 145
            val greenTable = g > r * 1.12 && g > b * 1.08 && g > 65
            val candidate = bright && !greenTable && (saturation > 0.28f || minC > 165)
            mask[i] = candidate
        }

        val seen = BooleanArray(w * h)
        val queue = IntArray(w * h)
        val found = ArrayList<DetectedBall>()
        for (seed in mask.indices) {
            if (!mask[seed] || seen[seed]) continue
            var head = 0; var tail = 0
            queue[tail++] = seed; seen[seed] = true
            var minX = w; var maxX = 0; var minY = h; var maxY = 0; var area = 0
            while (head < tail) {
                val p = queue[head++]
                val x = p % w; val y = p / w
                minX = minOf(minX, x); maxX = maxOf(maxX, x)
                minY = minOf(minY, y); maxY = maxOf(maxY, y)
                area++
                val neighbors = intArrayOf(
                    if (x > 0) p - 1 else -1,
                    if (x < w - 1) p + 1 else -1,
                    if (y > 0) p - w else -1,
                    if (y < h - 1) p + w else -1
                )
                for (n in neighbors) if (n >= 0 && mask[n] && !seen[n]) {
                    seen[n] = true
                    if (tail < queue.size) queue[tail++] = n
                }
            }
            val bw = maxX - minX + 1; val bh = maxY - minY + 1
            val ratio = bw.toFloat() / bh.coerceAtLeast(1)
            val fill = area.toFloat() / (bw * bh).coerceAtLeast(1)
            // Tamanho esperado aproximado de uma bola em imagem reduzida.
            if (area in 18..420 && bw in 5..34 && bh in 5..34 &&
                ratio in 0.68f..1.46f && fill > 0.42f) {
                var sumR = 0L; var sumG = 0L; var sumB = 0L; var count = 0
                for (yy in minY..maxY) for (xx in minX..maxX) {
                    val c = pixels[yy * w + xx]
                    sumR += Color.red(c); sumG += Color.green(c); sumB += Color.blue(c); count++
                }
                val ar = sumR / count.coerceAtLeast(1); val ag = sumG / count.coerceAtLeast(1); val ab = sumB / count.coerceAtLeast(1)
                val lowSat = maxOf(ar, ag, ab) - minOf(ar, ag, ab) < 58
                val brightNeutral = (ar + ag + ab) / 3 > 175
                found.add(DetectedBall(
                    x = ((minX + maxX) / 2f) * scale,
                    y = ((minY + maxY) / 2f) * scale,
                    radius = ((bw + bh) / 4f) * scale,
                    isCueCandidate = lowSat && brightNeutral
                ))
            }
        }
        return found.sortedByDescending { it.isCueCandidate }.take(24)
    }
}
