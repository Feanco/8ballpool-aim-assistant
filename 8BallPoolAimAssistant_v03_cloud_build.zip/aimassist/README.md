# 8 Ball Pool Aim Assistant PRO — v0.3

## O que foi adicionado
- Captura de tela com autorização explícita do Android (MediaProjection).
- Detector experimental por segmentação de cor e componentes conectados.
- Marcadores circulares sobre candidatos a bolas.
- Atualização de análise limitada a aproximadamente 2 quadros por segundo.
- A sobreposição é não interativa para não bloquear os toques no jogo.

## Como testar
1. Abra o projeto no Android Studio com Android SDK 36 instalado.
2. Execute no aparelho.
3. Permita sobreposição.
4. Inicie o detector e aceite a captura de tela do Android.
5. Abra uma partida de treino e observe os marcadores.

## Limitações
- A detecção é heurística e pode marcar elementos da interface ou perder bolas dependendo de brilho, tema, resolução e animações.
- A bola branca é apenas um candidato por cor; ainda não há identificação garantida.
- Esta versão marca posições detectadas, mas ainda não calcula trajetórias, colisões, ricochetes ou caçapas.
- Não lê memória do jogo, não altera o jogo e não executa tacadas.
- Código-fonte, não APK compilado. Compile no Android Studio.
- Como a sobreposição é não tocável, ela não intercepta os comandos do jogo.

## Próxima etapa
Calibrar a região da mesa e a escala das bolas usando capturas reais de diferentes partidas; depois, acrescentar cálculo geométrico das linhas de colisão.

## Gerar o APK usando somente o celular (GitHub Actions)

Este projeto inclui o fluxo `.github/workflows/build-apk.yml` para compilar o APK na nuvem, sem instalar Android Studio no celular.

1. Entre em https://github.com pelo navegador e crie uma conta ou faça login.
2. Crie um repositório novo (pode ser privado).
3. Envie os arquivos deste projeto para o repositório, mantendo a pasta `.github/workflows`.
4. Abra a aba **Actions** do repositório.
5. Se aparecer a opção, habilite os workflows. Depois escolha **Build Android APK** e toque em **Run workflow**.
6. Quando terminar com sucesso, abra a execução concluída e baixe o arquivo em **Artifacts**: `8BallPoolAimAssistant-debug-apk`.
7. Extraia o ZIP baixado e instale `app-debug.apk` no celular. O Android pode pedir autorização para instalar apps dessa origem.

Observação: este é um APK de depuração. O aplicativo ainda é um protótipo experimental; a identificação das bolas pode falhar e ele ainda não calcula trajetórias completas.
